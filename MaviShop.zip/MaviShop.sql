-- -----------------------------------------------------
-- Table `mydb`.`Role`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Role` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id`));



CREATE TABLE IF NOT EXISTS `Employee` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `fio` VARCHAR(100) NOT NULL,
  `age` INT NOT NULL,
  `adress` VARCHAR(100) NOT NULL,
  `phone` VARCHAR(45) NOT NULL,
  `login` VARCHAR(45) NOT NULL,
  `password` VARCHAR(45) NOT NULL,	
  `idRole` INT NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `idRole`
    FOREIGN KEY (`idRole`)
    REFERENCES `Role` (`id`)
    );



-- -----------------------------------------------------
-- Table `mydb`.`Category`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Category` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id`));



-- -----------------------------------------------------
-- Table `mydb`.`Product`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Product` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(50) NOT NULL,
  `price` INT NOT NULL,
  `discription` VARCHAR(200) NOT NULL,
  `photo` VARCHAR(45) NOT NULL,
  `idCategory` INT NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `idCategory`
    FOREIGN KEY (`idCategory`)
    REFERENCES `Category` (`id`)
    );



-- -----------------------------------------------------
-- Table `mydb`.`Status`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Status` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id`));



-- -----------------------------------------------------
-- Table `mydb`.`Order`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Order` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `price` INT NOT NULL,
  `data` DATE NOT NULL,
  `idStatus` INT NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `idStatus`
    FOREIGN KEY (`idStatus`)
    REFERENCES `Status` (`id`)
    );



-- -----------------------------------------------------
-- Table `mydb`.`order_product`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `order_product` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `order_id` INT NOT NULL,
  `product_id` INT NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `order_id`
    FOREIGN KEY (`order_id`)
    REFERENCES `Order` (`id`),
  CONSTRAINT `product_id`
    FOREIGN KEY (`product_id`)
    REFERENCES `Product` (`id`)
    );





